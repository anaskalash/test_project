<?php
  /**
  * @author Anas Kalash , Osama Hafar
  * @desc Database Configuration
  **/

class Config {
	
	const HOST_NAME 	= "localhost";
	const USERNAME 	    = "root";
	const DATABASE_NAME = "test";
	const PASSWORD 	    = "anas93";

	
}

